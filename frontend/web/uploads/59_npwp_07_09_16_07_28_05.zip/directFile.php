<?php

$url = "/userfiles/images/";
$dir = getcwd () . $url;
$allowImageExtension = array ('jpg', 'gif', 'png' );
$allowObjectExtension = array ('swf' );
$allowDataExtension = array ('zip','rar','xml','exe','mp3','pdf','doc','docx' );




$action = trim ( @$_REQUEST ['faction'] );
function getFileType($name) {
	global $allowImageExtension, $allowObjectExtension, $allowDataExtension;
	$ar = explode ( ".", $name );
	if (count ( $ar ) > 1) {
		$extension = array_pop ( $ar );
		if (in_array ( $extension, $allowImageExtension ))
			return 'image';
		if (in_array ( $extension, $allowObjectExtension ))
			return 'object';
		if (in_array ( $extension, $allowDataExtension ))
			return 'data';
	}
	return null;
}

function filelist() {
	global $dir, $url;
	
	$files = array ();
	$d = dir ( $dir );
	while ( true ) {
		$name = $d->read ();
		if ($name == false) {
			break;
		}
		if ($name == "." || $name == "..")
			continue;
		if (filetype ( $dir . $name ) == "dir")
			continue;
		$type = getFileType ( $name );
		if ($type === null)
			continue;
		
		$size = filesize ( $dir . $name );
		$lastmod = date ( "Y/m/d H:i", filemtime ( $dir . $name ) );
		list ( $w, $h, $fileType, $attr ) = @getimagesize ( $dir . $name );
		
		$files [] = array ('name' => $name, 'type' => $type, 'size' => $size, 'lastmod' => $lastmod, 'url' => $url . $name, 'w' => intval ( $w ), 'h' => intval ( $h ) );
	}
	$d->close ();
	$o = array ('files' => $files );
	echo json_encode ( $o );
}
function upload() {
	global $dir;
	$res = array ("success" => false );
	if (isset ( $_FILES ['files'] )) {
		$files = $_FILES ['files'];
		if (is_array ( $files ['name'] )) {
			$eFiles = array ();
			$sFiles = array ();
			foreach ( $files ['name'] as $k => $it ) {
				$name = $files ['name'] [$k];
				$type = $files ['type'] [$k];
				$tname = $files ['tmp_name'] [$k];
				$error = $files ['error'] [$k];
				$size = $files ['size'] [$k];
				
				if (getFileType ( $name ) !== null && $error == 0 && $size > 0) {
					move_uploaded_file ( $tname, $dir . $name ) ? $sFiles [] = $name : $eFiles [] = $name;
				} else {
					$eFiles [] = $name;
				}
			}
			
			if (count ( $eFiles ) == 0 && count ( $sFiles ) > 0) {
				$error = false;
			} else {
				$error = true;
			}
			$res ['success'] = ! $error;
			$res ['msg'] = $error ? 'can not upload. ' . implode ( ', ', $eFiles ) : '...';
			echo json_encode ( $res );
			return;
		}
	}
	
	$res ['msg'] = 'not found atache files';
	echo json_encode ( $res );
}
function delete() {
	global $dir;
	$file = $_REQUEST ['file'];
	$b = getFileType($file) !== null;
	if ($b && unlink ( $dir . $file ) === true) {
		echo "{success:true}";
	} else {
		echo "{success:false}";
	}
}
is_callable ( $action ) ? call_user_func ( $action ) : '';