<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>test</title>
<script type="text/javascript" src="Ext/adapter/ext/ext-base.js"></script>
<script type="text/javascript" src="Ext/ext-all-debug.js"></script>
<link type="text/css" rel="stylesheet" href="Ext/resources/css/reset-min.css" />
<link type="text/css" rel="stylesheet" href="Ext/resources/css/ext-all.css" />

<script type="text/javascript" src="Ext/ux/FileUploadField.js"></script>
<link type="text/css" rel="stylesheet" href="Ext/ux/file-upload.css" />

<script type="text/javascript" src="Ext/ux/HtmlEditor/FileManager/FileManager.js"></script>
<link type="text/css" rel="stylesheet" href="Ext/ux/HtmlEditor/FileManager/css/style.css" />
</head>

<body>
<script>
new Ext.form.HtmlEditor({
	renderTo: Ext.getBody(),
    width: 900,
    height: 300,
    plugins: [
		new Ext.ux.HtmlEditor.FileManager({
			url : 'directFile.php'
		})
	]
});
</script>
</body>
</html>