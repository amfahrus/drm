/*!
 * farcek@gmail.com
 * http://farcek.blogspot.com/
 */
/**
 * @class Ext.ux.HtmlEditor
 * @extends Ext.util.Observable 
 * Plugin (ptype = 'tabclosemenu') 
 * 
 * @pt
 */
Ext.ns('Ext.ux.HtmlEditor');

Ext.ux.HtmlEditor.FileManager = Ext.extend(Ext.util.Observable, {
	url : null,
	constructor: function(config){
		Ext.apply(this, config);
	},
	init: function(cmp){
	    this.cmp = cmp;
	    this.cmp.on('render', this.onRender, this);
	    
	},
	onRender : function(){
		
		this.cmp.getToolbar().addButton([new Ext.Toolbar.Separator()]);
        this.toolBtn = this.cmp.getToolbar().addButton({
            iconCls       : 'x-edit-FileManager',
            handler      : this.show,
            scope        : this,
            tooltip      : 'Insert image,swf and files',
        });
		this.toolBtn.disable();
	},
	show : function(){
		this.getWindow().show(this.toolBtn);
		this.getStore().reload();
	},
	getWindow : function(){
		if(this.win == null){
			this.win = new Ext.Window({
				title : 'File Manager',
				layout: 'border',
				cls : 'f-m-viewer',
				width: 600,
				height: 300,				
				modal: true,	
				maximizable : true,
				closeAction: 'hide',
				border: false,
				
				items:[this.winBody(),this.winTool()]
			});
		}
		return this.win;
	},
	getInsertBtn : function(){
		if(this._insertBtn == null){
			this._insertBtn = new Ext.SplitButton ({
				text : 'Insert',
				disabled : true,
				menu: new Ext.menu.Menu({
			        items: [
				        {text: 'Left' , id : 'btn-left', handler :this.insertClick.createDelegate(this,['left'])},
				        {text: 'Right', id : 'btn-right', handler :this.insertClick.createDelegate(this,['right'])},
				        {text: 'Middle', id : 'btn-middle', handler :this.insertClick.createDelegate(this,['middle'])}
			        ]
			   	}),
			   	handler : this.insertClick.createDelegate(this,['default'])
			});
		}
		return this._insertBtn;
	},
	insertClick : function (type){
		var view =this.getView();
		if(view.getSelectionCount() > 0){
			var data = view.getSelectedRecords()[0].data;
			
			if(data.type == "image") {
				var at = type || 'default';
				this.cmp.insertAtCursor('<img title="'+data.name+'" src="'+data.url+'" align="'+at+'" />');
				this.getWindow().hide();
			}else if(data.type == "data") {
				this.cmp.insertAtCursor('<a href="'+data.url+'" target="_blank">'+data.name+'</a>');
				this.getWindow().hide();
			}else if(data.type == "object") {
				var html = new Ext.Template('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,0,0,0" width="{w}" height="{h}" id="{name}">',
					'<param name="allowScriptAccess" value="sameDomain" />',
					'<param name="allowFullScreen" value="false" />',
					'<param name="movie" value="{url}" />',
					'<param name="quality" value="high" />',
					'<param name="wmode" value="transparent" />',
					'<embed src="{url}" quality="high" wmode="transparent" width="{w}" height="{h}" name="{name}" allowScriptAccess="sameDomain" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer" />',
				'</object>');
				this.cmp.append(html.apply(data));
				this.getWindow().hide();
			}
		}
		
	},
	deleteFile: function(name){
		if(name == "yes"){
			Ext.Ajax.request({
				url: this.url,
				callback: function(){
					this.getStore().reload();
					this.getView().refresh();
				},
				params: {
					faction: 'delete',
					file: this.tt_name					
				},
				scope: this
			});
		}
	},
	getDeleteBtn : function(){
		if(this._deleteBtn == null){
			this._deleteBtn = new Ext.Button ({
				text : 'Delete',
				disabled : true,
				handler : function(){
					var view =this.getView();
					if(view.getSelectionCount() > 0){
						
						var data = view.getSelectedRecords()[0].data;
						this.tt_name = data.name;
						
						Ext.Msg.confirm('Delete ?','Delete file : '+this.tt_name,this.deleteFile,this);						
					}
				},
				scope : this 
			});
		}
		return this._deleteBtn;
	},
	
	formatSize : function(data){
        if(data.size < 1024) {
            return data.size + " bytes";
        }else if(data.size < 1024*1024) {
        	return (Math.round(((data.size*10) / 1024))/10) + " KB";
        }else {
            return (Math.round(((data.size*100) / (1024*1024)))/100) + " MB";
        }
    },
    stringEllipse :function(str,len){
    	 if(str.length > len){
	        return str.substr(0, len-3) + '...';
	    }
    	 return str;
    },
	formatData : function(data){
		data.shortName = this.stringEllipse(data.name,15);
    	data.sizeString = this.formatSize(data);
    	//this.lookup[data.name] = data;
    	return data;
	},
	getView : function(){
		if(this._view == null){
			this._view = new Ext.DataView({
		        store: this.getStore(),
		        tpl: this.getViewTPL(),
		        autoHeight:true,
		        multiSelect: true,
		        overClass:'item-over',
		        itemSelector:'div.item',
		        emptyText: 'No images to display',
		        singleSelect : true,
		        multiSelect : false,
		        prepareData: this.formatData.createDelegate(this)
		    });
			this._view.on ('selectionchange',function(v,s){
				this.updateSelectFile();
			},this);
			this._view.on ('dblclick',function(v,s){
				this.insertClick();
			},this);
			
		}
		return this._view;
	},
	winTool : function (){
		if(this._winTool == null){
			this._winTool = new Ext.Panel ({
				region : 'east',
				width: 170,
				margins : {left :5},
				buttons : [this.getInsertBtn(),this.getDeleteBtn()]
			});
		}
		return this._winTool;
	},
	getNewUploadFiled : function(){
		return {
			xtype : 'fileuploadfield',
			emptyText: 'Select an image',
			hideLabel: true,
			name: 'files[]',
			anchor: '90%',
		};
	},
	getUploadWindow : function(){
		var frm = new Ext.FormPanel({
			region : 'center',
			fileUpload: true,
			frame: true,
			autoScroll : true,
			items : [{
				xtype : 'button',
				text : ' Add ',
				hideLabel : false,
				fieldLabel : 'Insert field',
				handler : function(){
					frm.add(this.getNewUploadFiled());
					frm.doLayout();  
				},
				scope : this 
			},this.getNewUploadFiled()]
		});
		var win = new Ext.Window({
			width: 330,
			height: 240,	
			layout: 'border',
			modal: true,	
			closeAction: 'close',
			border: false,
			title : 'File upload',
			resizable   : false,
			items : frm,
			buttons : [{
				text : 'Upload',
				handler : function (){
					frm.getForm().submit({
	                    url: this.url,
	                    params: {
	                        faction: 'upload'
	                    },
	                    waitMsg: 'Uploading files ..',
	                    success: function(form, action){
	                        //msg('Success', 'Processed file "'+o.result.file+'" on the server');
	                    	this.getStore().reload();
	                    	win.close();
	                    },
	                    failure: function(form, action) {
	                    	console.log(action);
	                    	Ext.Msg.alert('Failure', action.result.msg);
	                    },
	                    scope : this

	                });

				},
				scope : this
			},{
				text : 'Cancel',
				handler : function (){
					win.close();
				},
				scope : this 
			}]
		});
		
		return win;
	},
	winBody : function (){
		/*var fibasic = new Ext.ux.form.FileUploadField({
			buttonOnly: true,
			buttonText : 'Upload',
			listeners: {
	            'fileselected': function(fb, v){
					alert(11);
				}
			}
		});
		var fp = Ext.FormPanel({
			fileUpload: true,
			frame: true,
			 
		});*/
		
		var p = new Ext.Panel ({
			region : 'center',
			autoScroll: true,
			items : this.getView(),
			buttons : [{
				text : 'Upload',
				handler : function(){
					this.getUploadWindow().show();
				},
				scope : this 
			}]
		});
		
		return p;
	},
	getStore : function(){
		if(this.store == null){
			this.store = new Ext.data.JsonStore({
			    url: this.url,
				baseParams : {faction  : 'filelist'},
			    root: 'files',
			    fields: [
			        'name', 'url', 'type', 'lastmod', 'w', 'h',
			        {name:'size', type: 'float'}
			    ]/*,
			    listeners: {
			    	'load': {fn:function(){ this.view.select(0); }, scope:this, single:true}
			    }*/
			});
			this.store.on ('loadexception',function(v,s){
				this.getView().getEl().update('<div style="padding:10px;">Error loading.</div>');
			},this);
			//this.store.load();
		}
		return this.store;
	},
	getViewTPL : function (){
		if(this._viewtpl == null){
			this._viewtpl = new Ext.XTemplate(
				'<tpl for=".">',
				'<div class="item" id="{name}">',
					'<tpl if="this.isIamge(type)">',
			        	'<table border="0"><tr><td valign="middle" align="center" class="image"><img src="{url}" title="{name}" /></td></tr></table>',
				    '</tpl>',
				    '<tpl if="this.isData(type)">',
					    '<div class="data"> &nbsp; </div>',
				    '</tpl>',
				    '<tpl if="this.isObject(type)">',
				    	'<div class="object"> &nbsp; </div>',
				    '</tpl>',
				    '<div class="label">{shortName}</div>',
				'</div>',
			    '</tpl>',
			    '<div class="x-clear"></div>', {
					isIamge: function(t){
						return t == 'image';
					},
					isObject: function(t){
						return t == 'object';
					},
					isData: function(t){
						return t == 'data';
					}
				}
			);
		}
		return this._viewtpl;
	},
	getInfoTPL : function (){
		if(this._infoTpl == null){
			this._infoTpl = new Ext.XTemplate(
				'<div class="info">',
					'<tpl if="this.isIamge(type)">',
			        	'<table border="0"><tr><td valign="middle" align="center" class="image"><img src="{url}" title="{name}" /></td></tr></table>',
			        	'<div class="image-size"> {w}x{h} </div>',
				    '</tpl>',
				    '<tpl if="this.isData(type)">',
					    '<div class="data"> &nbsp; </div>',
				    '</tpl>',
				    '<tpl if="this.isObject(type)">',
				    	'<div class="object"> &nbsp; </div>',
				    	'<div class="image-size"> {w}x{h} </div>',
				    '</tpl>',
				    
				    '<div class="row"> Name   <b>{name}</b> </div>',
				    '<div class="row"> Size   <b>{sizeString}</b> </div>',
				    '<div class="row"> Date   <b>{lastmod}</b> </div>',
				'</div>',{
					isIamge: function(t){
						return t == 'image';
					},
					isObject: function(t){
						return t == 'object';
					},
					isData: function(t){
						return t == 'data';
					}
				}
			);
		}
		return this._infoTpl;
	},
	updateSelectFile : function(){
		var view =this.getView();
		if(view.getSelectionCount() > 0){
			this.getInsertBtn().enable();
			this.getDeleteBtn().enable();
			
			var data = view.getSelectedRecords()[0].data;
			var el = this.winTool().body;
			this.getInfoTPL().overwrite(el, data);
			el.slideIn('t', {stopFx:true,duration:.2});
			if(data.type =="image"){
				this.getInsertBtn().menu.get('btn-left').enable();
				this.getInsertBtn().menu.get('btn-right').enable();
				this.getInsertBtn().menu.get('btn-middle').enable();
			}else{
				this.getInsertBtn().menu.get('btn-left').disable();
				this.getInsertBtn().menu.get('btn-right').disable();
				this.getInsertBtn().menu.get('btn-middle').disable();
			}
			
		}else{
			this.getInsertBtn().disable();
			this.getDeleteBtn().disable();
			var el = this.winTool().body;
			el.update('');
		}
		
	}
});
Ext.preg('ffilemanage', Ext.ux.HtmlEditor.FileManager);